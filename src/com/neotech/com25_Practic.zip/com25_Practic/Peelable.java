package com.neotech.com25_Practic;

public interface Peelable {

     void peel ();


}

interface Washable {
	
	void wash ();
	

















}